/***************** Libraries *****************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>


/***************** Structures *****************/

/***************** Constants *****************/

/***************** Globals *****************/

/***************** Function Prototypes *****************/
void SetRandomSeed(void);
void StartupText(void);
void Initialise(int argc, char **argv);
void Start(void);
void Wait(void);

/***************** Error Messages *****************/
